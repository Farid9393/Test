import React, { useState } from 'react';
import './App.css';

function App() {
  const [pseudo, setPseudo] = useState("");
  const [post, setPost] = useState("");
  const [posts, setPosts] = useState([]);

  const handlePost = () => {
    if (post.trim()) {
      setPosts([{ text: post, author: pseudo }, ...posts]);
      setPost("");
    }
  };

  if (!pseudo) {
    return (
      <div className="container">
        <h1>Choisis ton pseudo</h1>
        <input type="text" placeholder="Ton pseudo..." onChange={(e) => setPseudo(e.target.value)} />
      </div>
    );
  }

  return (
    <div className="container">
      <h1>Bienvenue, {pseudo}</h1>
      <div className="post-creator">
        <textarea placeholder="Exprime-toi..." value={post} onChange={(e) => setPost(e.target.value)} />
        <button onClick={handlePost}>Publier</button>
      </div>
      <div className="posts">
        {posts.map((p, i) => (
          <div key={i} className="post">
            <div className="post-header">
              <strong>{p.author}</strong>
              <button title="Signaler ⚠️">⚠️</button>
            </div>
            <p>{p.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;